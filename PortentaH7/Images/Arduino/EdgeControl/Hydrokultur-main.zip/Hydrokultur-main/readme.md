![GitHub Logo](http://www.heise.de/make/icons/make_logo.png)

Maker Media GmbH
*** 

# Hydroponikanlage mit ESP32-Steuerung
Gemüse auf dem Balkon züchten

### Salat und Gemüse aus der Hydroponikanlage

Auch mit wenig Platz lassen sich Salat und Gemüse selbst anziehen und automatisch im geschlossenen Kreislauf bewässern. Mit Teilen aus dem Baumarkt und einem ESP32 als Steuerung ist diese Anlage schnell gebaut und individuell anpassbar.

![Picture](https://github.com/MakeMagazinDE/Hydrokultur/blob/main/Hydrokultur.jpg)

Den vollständigen Artikel mit der Bauanleitung gibt es in der [Make-Ausgabe 1/2021](https://www.heise.de/select/make/2021/1/seite-36) zu lesen. 
